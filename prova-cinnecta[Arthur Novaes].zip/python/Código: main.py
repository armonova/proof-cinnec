Código: main.py
Autor: Arthur Novaes


1. Explicação das funções:

1.1. check_words_on_files
	Essa função retorna o vocabulário de um determinado arquivo passado como parâmetro. O vocabulário é montado dado o número da sequência de palavras que deve ser informado na chamada da função.
	Além disso essa função recebe como parâmetro um vocabulário, para o caso de montar um vocabulário com mais de um arquivo. Se for desejável montar o vocabulário a partir de dois arquivos de entrada, deve-se pegar o retorno da primeira vez que a função for chamada e inserir esse vocabulário na próxima vez que for chamada a função. Se nessa entrada da função for passada uma lista vazia o retorno será o vocabulário apenas do arquivo também passado como entrada da função.

1.2 count_words_on_file
	Essa função, dado um arquivo de entrada e um dicionário, irá contar o número de ocorrências de cada palavra daquele arquivo
	Como parâmetro de entrada dessa função também deve ser informado qual o número da sequência de palavras é formado o vocabulário.

1.3 file_to_string
	Essa é uma função auxiliar que retorna às palavras de um arquivo passado como parâmetro em uma lista.
	Também deve ser informado na chamada da função qual o número da sequência de palavras, para que o retorno seja adequado à esse número.